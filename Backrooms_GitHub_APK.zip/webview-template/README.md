# Backrooms Level 0 — Android APK

Готовый проект для сборки APK через **GitHub Actions** (без компьютера и Android Studio).

## Как получить APK (с телефона)

1. Создай аккаунт на [GitHub.com](https://github.com) если ещё нет.
2. Создай **новый репозиторий** (New repository) — любое имя, например `backrooms-apk`.
3. Залей **все файлы** из этой папки в репозиторий:
   - Можно через приложение **GitHub** на телефоне
   - Или через сайт: Upload files → выбери всю папку
4. После загрузки GitHub **сам запустит сборку** (Actions).
5. Зайди во вкладку **Actions** → последний workflow → скачай артефакт **Backrooms**.
6. Распакуй zip и установи `Backrooms.apk` на телефон.

> Если сборка не запустилась — зайди в Actions и нажми **Run workflow**.

## Что внутри

- Игра полностью оффлайн (все звуки, текстуры, шрифты внутри APK)
- Принудительный **альбомный** режим (landscape)
- Полноэкранный immersive-режим (без панелей)
- localStorage для сохранений

## Структура

```
assets/          ← вся игра (index.html + fonts + js + sounds + textures)
src/             ← WebView оболочка
res/             ← иконка и стили
AndroidManifest.xml
.github/workflows/build-apk.yml  ← автоматическая сборка
```

Удачи в бэкрумах.
